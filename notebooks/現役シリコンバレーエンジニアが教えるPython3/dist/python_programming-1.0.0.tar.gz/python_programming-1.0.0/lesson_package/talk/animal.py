from lesson_package.tools import utils


def sing():
    return 'sdfasfaerterfasf'


def cry():
    return utils.say_twice('asfasfasfasfasd')
